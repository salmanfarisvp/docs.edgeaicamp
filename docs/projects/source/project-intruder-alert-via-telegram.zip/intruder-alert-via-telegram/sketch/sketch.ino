#include <Arduino_RouterBridge.h>
#define buzzer 10

// This function receives an integer (1 or 0) from Python
void control_led(int state) {

  if (state == 1) {
    digitalWrite(LED_BUILTIN, LOW);  // Turn LED ON (Active Low)
    digitalWrite(buzzer, HIGH);
    Monitor.println("LED is ON");
  } else {
    digitalWrite(LED_BUILTIN, HIGH); // Turn LED OFF
    digitalWrite(buzzer, LOW);
    Monitor.println("LED is OFF");
  }

}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(buzzer, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH); // Turn LED OFF (Active Low)
  digitalWrite(buzzer, LOW);

  Bridge.begin();
  Monitor.begin();
  Bridge.provide_safe("control_led", control_led);
}

void loop() {
  // Bridge runs automatically in the background
}

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_imageclassification import VideoImageClassification
from arduino.app_peripherals.camera import Camera
from arduino.app_bricks.telegram_bot import TelegramBot, Sender, Message
from arduino.app_utils.image.adjustments import compress_to_jpeg
from datetime import datetime, UTC
import json
import os
import time


ui = WebUI()

camera = Camera(resolution=(640, 480), fps=30)
detection_stream = VideoImageClassification(camera=camera, confidence=0.5, debounce_sec=1.0)

def on_override_threshold(sid, threshold):
    try:
        detection_stream.override_threshold(threshold)
    except Exception as e:
        print(f"Could not override threshold: {e}")

ui.on_message("override_th", on_override_threshold)

bot = TelegramBot()
ALERT_CHAT_FILE = os.path.join(os.path.dirname(__file__), "alert_chat_id.txt")

# Chat ID is learned from Telegram (/start), not hardcoded.
alert_chat_id = None

# Only act when a person appears or leaves, so Telegram is not spammed.
person_present = False
pending_alert = False

# After sending one photo, wait this many seconds before sending another.
IMAGE_COOLDOWN_SEC = 30
last_photo_time = 0.0


def load_alert_chat_id():
    try:
        with open(ALERT_CHAT_FILE, "r", encoding="utf-8") as f:
            value = f.read().strip()
        return int(value) if value else None
    except (FileNotFoundError, ValueError, OSError):
        return None


def save_alert_chat_id(chat_id):
    try:
        if chat_id is None:
            os.remove(ALERT_CHAT_FILE)
            return
        with open(ALERT_CHAT_FILE, "w", encoding="utf-8") as f:
            f.write(str(chat_id))
    except FileNotFoundError:
        pass
    except OSError as e:
        print(f"Could not save alert chat id: {e}")


alert_chat_id = load_alert_chat_id()


def notify_text(text: str):
    if alert_chat_id is None:
        print(f"No Telegram chat registered. Open the bot and send /start. ({text})")
        return False
    return bot.send_message(alert_chat_id, text)


def remember_chat(sender: Sender) -> bool:
    """Save this Telegram chat for later alerts. Returns True if it is a new chat."""
    global alert_chat_id
    is_new = alert_chat_id != sender.chat_id
    alert_chat_id = sender.chat_id
    if is_new:
        save_alert_chat_id(alert_chat_id)
        print(f"Telegram chat registered: {alert_chat_id}")
    return is_new


def send_pending_photo_if_needed():
    global pending_alert
    if person_present or pending_alert:
        pending_alert = False
        send_intruder_photo()


def register_chat(sender: Sender, message: Message):
    remember_chat(sender)
    sender.reply("This chat is registered for intruder alerts. Send /stop to unregister.")
    send_pending_photo_if_needed()


def unregister_chat(sender: Sender, message: Message):
    global alert_chat_id
    alert_chat_id = None
    save_alert_chat_id(None)
    sender.reply("This chat will no longer receive intruder alerts.")


bot.add_command("start", register_chat, "Register this chat for alerts")
bot.add_command("stop", unregister_chat, "Stop receiving alerts")


def set_alarm(on: bool):
    try:
        Bridge.call("control_led", 1 if on else 0)
    except Exception as e:
        print(f"Bridge LED/buzzer call failed: {e}")


def send_intruder_photo():
    global last_photo_time

    if alert_chat_id is None:
        print("Person detected, but no Telegram chat is registered. Send /start to the bot.")
        return

    now = time.monotonic()
    elapsed = now - last_photo_time
    if elapsed < IMAGE_COOLDOWN_SEC:
        return

    # Stamp immediately so the next 30s of detections cannot burst photos.
    last_photo_time = now
    print("Sending intruder photo")

    try:
        captured_frame = camera.capture()
        if captured_frame is None:
            notify_text("🚨 Intruder Detected! (Camera capture returned empty)")
            return

        jpeg_frame = compress_to_jpeg(captured_frame)
        if jpeg_frame is None:
            notify_text("🚨 Intruder Detected! (Could not encode photo)")
            return

        image_bytes = jpeg_frame.tobytes()
        if bot.send_photo(alert_chat_id, image_bytes, caption="🚨 Intruder Detected!"):
            print("Photo sent to Telegram successfully")
            return

        print("Telegram photo send failed, sending text instead")
        notify_text("🚨 Intruder Detected! (Photo upload failed)")

    except Exception as e:
        print(f"Capture/send error: {e}")
        notify_text(f"🚨 Intruder Detected! (Camera error: {e})")


def person_detected():
    global person_present, pending_alert
    if not person_present:
        person_present = True
        print("Person detected")
        set_alarm(True)

    if alert_chat_id is None:
        pending_alert = True
        print("Person detected, but no Telegram chat is registered. Send /start to the bot.")
        return

    # Keep trying while the person stays in view. send_intruder_photo()
    # sends immediately, then only again after IMAGE_COOLDOWN_SEC.
    send_intruder_photo()


def person_not_detected():
    global person_present
    if not person_present:
        return
    person_present = False
    print("Person left")
    set_alarm(False)


detection_stream.on_detect("person", person_detected)
detection_stream.on_detect("non person", person_not_detected)


def send_detections_to_ui(classifications: dict):
    if len(classifications) == 0:
        return

    entries = []
    for key, value in classifications.items():
        entries.append({
            "content": key,
            "confidence": value,
            "timestamp": datetime.now(UTC).isoformat()
        })

    if len(entries) > 0:
        ui.send_message("classifications", message=json.dumps(entries))


detection_stream.on_detect_all(send_detections_to_ui)

App.run()
